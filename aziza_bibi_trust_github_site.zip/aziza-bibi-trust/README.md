# Aziza Bibi Trust — simple website

A lightweight, responsive one-page website built with plain HTML and CSS. No frameworks, build tools, or dependencies are required.

## Preview locally
Open `index.html` in any browser.

## Publish with GitHub Pages
1. Create a new GitHub repository (for example, `aziza-bibi-trust`).
2. Upload `index.html` and `README.md` to the repository's root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. GitHub will provide the published website link after deployment.

## Before publishing
Review the wording and add verified contact or donation details only if you want them public. The current page intentionally does not display personal account information.
